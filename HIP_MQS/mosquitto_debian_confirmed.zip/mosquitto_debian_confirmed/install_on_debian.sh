#!/bin/bash
echo "🔄 Instalando mosquitto-clients en Debian..."

# Instalar en orden correcto
sudo dpkg -i libc-ares2_*.deb 2>/dev/null || true
sudo dpkg -i libssl3_*.deb 2>/dev/null || true
sudo dpkg -i libuv1_*.deb 2>/dev/null || true
sudo dpkg -i libmosquitto1_*.deb
sudo dpkg -i mosquitto-clients_*.deb

# Corregir dependencias si es necesario
sudo apt-get install -f -y

echo "✅ Verificando instalación..."
mosquitto_sub --help | head -5
