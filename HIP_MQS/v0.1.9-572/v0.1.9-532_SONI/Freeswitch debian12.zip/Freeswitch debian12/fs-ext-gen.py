import os, sys

def create_extension_file(extension_number, directory):
    filename = f"{extension_number}.xml"
    filepath = os.path.join(directory, filename)
    
    extension_content = f"""
<include>
  <user id="{extension_number}">
    <params>
      <param name="password" value="$${{default_password}}"/> 
    </params>
    <variables>
      <variable name="toll_allow" value="local"/>
      <variable name="user_context" value="default"/>
      <variable name="effective_caller_id_name" value="{extension_number}"/>
      <variable name="effective_caller_id_number" value="{extension_number}"/>
      <variable name="outbound_caller_id_name" value="$${{outbound_caller_name}}"/>
      <variable name="outbound_caller_id_number" value="$${{outbound_caller_id}}"/>
    </variables>
  </user>
</include>
"""
    with open(filepath, 'w') as file:
        file.write(extension_content)

def generate_extensions(start, end, directory):
    if not os.path.exists(directory):
        os.makedirs(directory)
    
    for number in range(start, end + 1):
        create_extension_file(number, directory)
    print(f"Extension files created in {directory}")

# Define the range of extension numbers
start_number = 1000
end_number = 1010

# Define the directory where files will be saved
output_directory = "freeswitch_extensions"

# Main program

global first_ext, last_ext, output_dir

first_ext = 1
last_ext = 1
output_dir = ""

def error(msg):
    print(msg)
    sys.exit(1)

def check_arg( arg, var_name, var_type ):
    try:
        if var_type == int:
            return int(arg)
        elif var_type == str:
            return str(arg)
        else:
            raise ValueError
    except ValueError:
        error ( f"{var_name} = {arg} is not {var_type.__name__}\n" )

# Analisis de invocacion

my_name = sys.argv[0]
args_qty = len(sys.argv)

if args_qty != 4:
    error (
        f"python3 {my_name} <first_ext_no> <last_ext_no> <output_dir>\n"
        f"(Ej: {my_name} 100 119 /etc/freeswitch/directory/surix-directory"
    )

first_ext   = check_arg( sys.argv[1], "first_ext", int )
last_ext    = check_arg( sys.argv[2], "last_ext", int )
output_dir  = check_arg( sys.argv[3], "output_dir", str )

# print ( f"{my_name} {first_ext} {last_ext} {output_dir}\n" )

if last_ext <= first_ext:
    error ( f"last_ext_no ({last_ext}) needs to be greater than first_ext_no ({first_ext}}}\n" )

if not os.path.exists(output_dir):
    print( f"Directory {output_dir} doesn't exist\n" )
    user_input = input ( "Create it? [y/n] " )
    if user_input.lower() != 'y':
        error ( "Aborting\n" )
    try:
        os.mkdir(output_dir)
        print( f"Directory {output_dir} created\n" )
    except:
        error( f"Can not create {output_dir}\nAborting\n" )

# Generate the extension files
generate_extensions( first_ext, last_ext, output_dir )
