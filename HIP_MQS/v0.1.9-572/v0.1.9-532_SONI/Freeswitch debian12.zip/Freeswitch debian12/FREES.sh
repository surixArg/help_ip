#!/bin/bash

echo "Para proseguir con la instalación debe tener los archivos descargados junto a este script en la carpeta en la que se incluyen los archivos y la guía, y también debe tener dicha carpeta en su carpeta personal o "Home", una cuenta en signalwire.com y una personal access token, a su vez debe haber ejecutado este archivo desde una terminal con root, si ya tiene los requisitos prosiga, en caso contrario ejecute CTRL + C"
sleep 10
cd /usr/src
echo "cd /usr/src"
systemctl restart NetworkManager
echo "systemctl restart NetworkManager"
sleep 3
echo "sleep 3"
apt-get update && apt-get upgrade && apt install curl && apt install git && apt install make && apt install python3
echo "apt-get update && apt-get upgrade && apt install curl && apt install git && apt install make && apt install python3"
FSfile=$(curl -s https://files.freeswitch.org/releases/freeswitch/ | grep -oE "freeswitch-[0-9]*\.[0-9]*\.[0-9]*\.-release\.tar\.bz2" | tail -n 1) && echo Downloading $FSfile && curl https://files.freeswitch.org/freeswitch-releases/$FSfile | tar -xj && mv ${FSfile/.tar.bz2//} freeswitch
echo "FSfile=$(curl -s https://files.freeswitch.org/releases/freeswitch/ | grep -oE "freeswitch-[0-9]*\.[0-9]*\.[0-9]*\.-release\.tar\.bz2" | tail -n 1) && echo Downloading $FSfile && curl https://files.freeswitch.org/freeswitch-releases/$FSfile | tar -xj && mv ${FSfile/.tar.bz2//} freeswitch"
cd freeswitch
echo "cd freeswitch"
git clone https://github.com/signalwire/freeswitch.git -b v1.10
echo "git clone https://github.com/signalwire/freeswitch.git -b v1.10"
cd freeswitch
echo "cd freeswitch"
echo "Inserte su 'personal access token' de signalwire.com, ejemplo: pat_shjij25jk1Ba9kWsnap respetando mayúsculas y poniendo el 'pat_'"
read PAT
TOKEN=$PAT
echo "TOKEN=$PAT"
apt-get update && apt-get install -y gnupg2 wget lsb-release
echo "apt-get update && apt-get install -y gnupg2 wget lsb-release"
echo "machine freeswitch.signalwire.com login signalwire password $TOKEN" > /etc/apt/auth.conf
chmod 600 /etc/apt/auth.conf
echo "deb [signed-by=/usr/share/keyrings/signalwire-freeswitch-repo.gpg] https://freeswitch.signalwire.com/repo/deb/debian-release/ `lsb_release -sc` main" > /etc/apt/sources.list.d/freeswitch.list
echo "deb-src [signed-by=/usr/share/keyrings/signalwire-freeswitch-repo.gpg] https://freeswitch.signalwire.com/repo/deb/debian-release/ `lsb_release -sc` main" >> /etc/apt/sources.list.d/freeswitch.list
apt-get update && apt-get install -y freeswitch-meta-all
echo "apt-get update && apt-get install -y freeswitch-meta-all"
echo "A continuación, una vez finalizada la instalación de freeswitch vamos a configurar algunos parámetros para el funcionamiento buscado"
cd /etc/freeswitch/sip_profiles
mv internal_ipv6.xml internal_ipv6.xml.noload
mv external_ipv6.xml external_ipv6.xml.noload
cd /etc/freeswitch
mv vars.xml vars.xml.noload
cd /etc/freeswitch/autoload_configs
mv modules.conf.xml modules.conf.xml.noload
cd /etc/freeswitch/dialplan
mv default.xml default.xml.noload
cd ~
mv vars.xml /etc/freeswitch
mv modules.conf.xml /etc/freeswitch/autoload_configs
mv default.xml /etc/freeswitch/dialplan
mv fs-ext-gen.py 
echo "El proceso a terminado, a partir de ahora podrá encender el servidor freeswitch con el siguiente comando: freeswitch -nonat"
echo "En el caso de que haya fallado la instalación les recomendamos que sigan la guía y ejecuten paso por paso"
freeswitch -nonat
